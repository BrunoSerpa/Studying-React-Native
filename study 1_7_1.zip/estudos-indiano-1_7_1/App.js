import React, {useState} from 'react';
import {StyleSheet, Pressable, Text, TextInput, View} from 'react-native';
import Constants from 'expo-constants';
export default function App() {
  const[nome, mudaNome] = useState('');
  const[enviado, mudaEnviado] = useState('');
  const aoPrecionarModifica = () => {
    mudaEnviado(!enviado)

  }
  return (
    <View style={Estilos.Item}>
    <Text style={Estilos.Texto}>Por favor, escreva seu nome:</Text>
    <TextInput style={Estilos.TextoDeEntrada} placeholder='por exemplo: Bruno' onChangeText={(valor)=>mudaNome(valor)}/>
    <Pressable style={()=>[{backgroundColor: enviado?'#dddddd':'#00ff00'},
      Estilos.Botao]} hitSlop={{top: 10, bottom: 10, right: 10, left: 10}} onPress={aoPrecionarModifica}>
    <Text style={Estilos.Texto}> {enviado?'Limpar':'Segure'}</Text>
    </Pressable>
    {enviado?
      <Text style={Estilos.Texto}> Seu nome é {nome}</Text> : null
    }
    </View>
  );
}
const Estilos = StyleSheet.create({
  Item: {margin:10, backgroundColor: '#ffffff', justifyContent: 'center', alignItems: 'center'},
  Botao: {width:150, height:50, borderRadius: 15, alignItems: 'center'},
  Texto: {color: '#000000', fontSize: 20, margin: 10},
  TextoDeEntrada: {borderColor: '#000000', borderWidth: 1, borderRadius: 5,color: '#000000', fontSize: 15, margin: 10, textAlign: 'CENTER', width:200},
});
