import React, {useState} from 'react';
import {Button, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  const [quantidadeDeCliques, mudaQuantidadeDeCliques] = useState(0)
  const [numero, mudaNumero] = useState(0)
  const [singularOuPlural, mudaSingularOuPlural] = useState('vezes')
  const bottaoClicado = () => {
    mudaQuantidadeDeCliques(quantidadeDeCliques + 1)
    mudaSingularOuPlural('vez')
    if (quantidadeDeCliques > 0){mudaSingularOuPlural('vezes')}
    mudaNumero(5 * quantidadeDeCliques)
  }
  return (
    <View style={Estilos.Corpo}>
      <Text style={Estilos.Texto}> {numero} </Text>
      <Button title='Adicionar' onPress={bottaoClicado}></Button>
      <Text style={Estilos.Texto}>Você clicou {quantidadeDeCliques} {singularOuPlural} </Text>
    </View>
  );
}
const Estilos = StyleSheet.create({
  Corpo: {flex: 1, backgroundColor: '#0000ff', alignItems: 'center', justifyContent: 'center'},
  Texto: {color: '#ffffff', fontSize: 20, fontStyle: 'italic', margin: 10},
});
