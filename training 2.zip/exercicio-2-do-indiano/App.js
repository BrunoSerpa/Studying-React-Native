import React, {useState} from 'react';
import {Button, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  return (
    <View style={Estilos.CorpoPrincipal}>
      <View style={Estilos.Corpo1}>
        <View style={Estilos.Estilo1}>
          <Text style={Estilos.Texto}>1</Text>
        </View>
        <View style={Estilos.Estilo2}>
          <Text style={Estilos.Texto}>2</Text>
        </View>
        <View style={Estilos.Estilo3}>
          <Text style={Estilos.Texto}>3</Text>
        </View>
      </View>
      <View style={Estilos.Corpo2}>
          <Text style={Estilos.Texto}>4</Text>
      </View>
      <View style={Estilos.Corpo3}>
          <Text style={Estilos.Texto}>5</Text>
      </View>
      <View style={Estilos.Corpo4}>
        <View style={Estilos.Estilo4}>
          <Text style={Estilos.Texto}>6</Text>
        </View>
        <View style={Estilos.Estilo5}>
          <Text style={Estilos.Texto}>7</Text>
        </View>
      </View>
    </View>

  );
}
const Estilos = StyleSheet.create({
  CorpoPrincipal: {flex:1, flexDirection:'coluwn', backgroundColor: '#0000ff', alignItems: 'stretch', justifyContent: 'center',},
  Corpo1: {flex:1, flexDirection:'row', backgroundColor: '#0000ff', alignItems: 'stretch', justifyContent: 'center',},
  Corpo2: {flex:1, backgroundColor: '#ff000f', alignItems: 'center', justifyContent: 'center',},
  Corpo3: {flex:1, backgroundColor: '#0fff00', alignItems: 'center', justifyContent: 'center',},
  Corpo4: {flex:6,flexDirection:'row', backgroundColor: '#ff000f', alignItems: 'stretch', justifyContent: 'center',},
  Estilo1: {flex:1, backgroundColor: '#00ffff', alignItems: 'center', justifyContent: 'center',},
  Estilo2: {flex:2, backgroundColor: '#ff00ff', alignItems: 'center', justifyContent: 'center',},
  Estilo3: {flex:3, backgroundColor: '#ffff00', alignItems: 'center', justifyContent: 'center',},
  Estilo4: {flex:3, backgroundColor: '#ffffff', alignItems: 'center', justifyContent: 'center',},
  Estilo5: {flex:3, backgroundColor: '#000fff', alignItems: 'center', justifyContent: 'center',},
  Texto: {color: '#000000', fontSize: 40, fontStyle: 'italic', margin: 10,},
});
