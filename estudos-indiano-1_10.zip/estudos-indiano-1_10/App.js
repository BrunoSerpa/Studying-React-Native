import React, {useState} from 'react';
import {Alert, StyleSheet,
  View,
  Text,
  TextInput,
  Pressable, Modal} from 'react-native';
import Constants from 'expo-constants';
export default function App() {
  const[nome, mudaNome] = useState('');
  const[enviado, mudaEnviado] = useState('');
  const[mostrarAviso, mudaMostrarAviso] = useState('');
  const aoPrecionarModifica = () => {
    if (nome.length > 3){mudaEnviado(!enviado)}
    else{mudaMostrarAviso(true)}}
  return (
    <View style={Estilos.Item}>
      <Text style={Estilos.Texto}>Por favor, escreva seu nome:</Text>
      <Modal 
      visible={mostrarAviso} transparent onRequestClose={() => mudaMostrarAviso(false)}>
        <View style={Estilos.ConteinerCentralizado}>
          <View style={Estilos.ConteinerModal}>
          <View style={Estilos.ConteinerModalTitulo}>
            <Text  style={Estilos.Texto}>Atenção</Text>
          </View>
          <View style={Estilos.ConteinerModalCorpo}>
            <Text  style={Estilos.Texto}>O nome deve ter mais do que 3 caractéres</Text>
          </View>
          <Pressable onPress={() => mudaMostrarAviso(false)} style={Estilos.ModalBotao}
           android_ripple={{color:'#fff'}} animationType='slide' hardwareAccelerated>
          <Text style={Estilos.Texto}> {enviado?'Limpar':'Clique'} </Text>
          </Pressable>
          </View>
        </View>
      </Modal>
      <TextInput style={Estilos.TextoDeEntrada} placeholder='por exemplo: Bruno' 
        onChangeText={(valor)=>mudaNome(valor)}/>
      
      {/* <Button
        title={enviado?'Limpar':'Clique'}
        onPress={aoPrecionarModifica}
        color='#00f'
      /> */}
      {/* <TouchableWithoutFeedback
        onPress={aoPrecionarModifica}
      >
        <View style={Estilos.Botao}>
          <Text style={Estilos.Texto}>
            {enviado?'Limpar':'Clique'}
          </Text>
        </View>
      </TouchableWithoutFeedback> */}
      <Pressable style={({apertou})=>[{backgroundColor: apertou?'#dddddd':'#00ff00'},
        Estilos.Botao]} hitSlop={{top: 10, bottom:10, left:10, right:10}}
        android_ripple={{color:'#00f'}}
        onPress={aoPrecionarModifica}>
      <Text style={Estilos.Texto}> {enviado?'Limpar':'Clique'} </Text>
      </Pressable>
      {enviado?<Text style={Estilos.Texto}> Seu nome é {nome}</Text> : null}
    </View>
  );
}
const Estilos = StyleSheet.create({
  Item: {margin: 10, backgroundColor: '#ffffff', justifyContent: 'center', alignItems: 'center'},
  ConteinerCentralizado: {flex: 1, justifyContent: 'center', alignItems: 'center',backgroundColor: '#999'},
  ConteinerModal: {width: 300, height: 300, backgroundColor: '#ffffff', borderWidth:1, borderColor: '#000', borderRadius: 20},
  ConteinerModalTitulo: {height: 50,  justifyContent: 'center', alignItems: 'center', backgroundColor:'#ff0', borderTopLeftRadius: 20, borderTopRightRadius: 20},
  ConteinerModalCorpo: {height: 200,  justifyContent: 'center', alignItems: 'center', textAlign: 'center'},
  ModalBotao: {backgroundColor: '#00ffff', borderBottomLeftRadius: 20, borderBottomRightRadius: 20},
  Botao: {width: 150, height: 50, borderRadius: 15, alignItems: 'center'},
  Texto: {color: '#000000', fontSize: 20, margin: 10},
  TextoDeEntrada: {borderColor: '#000000', borderWidth: 1, borderRadius: 5, color: '#000000',
    fontSize: 15, margin: 10, textAlign: 'center', width: 200},
});