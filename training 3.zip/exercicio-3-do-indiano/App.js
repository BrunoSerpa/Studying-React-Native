import React, {useState} from 'react';
import {RefreshControl, ScrollView, SectionList, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';
export default function App() {
  const [Dados, definirDados] = useState([
    {titulo: 'Título 1', data: ['Item 1-1', 'Item 1-2']}
  ]);
  const [Atualizar, definirAtualizar] = useState(false);
  const aoAtualizar = () => {
    definirAtualizar(true);
    const novoDado = Dados.length + 1;
    definirDados([...Dados,
    {
      titulo: 'Título ' + novoDado,
      data: ['Item' + novoDado + '-1', 'Item' + novoDado + '-2']
    }
    ]);
    definirAtualizar(false);
  }
  return (
    <SectionList
      keyExtractor={(item, caixa) => caixa.toString()}
      sections={Dados}
      renderSectionHeader={({section}) => (
        <View style={Estilo.fundoTitulo}>
          <Text style={Estilo.textoTitulo}>{section.titulo}</Text>
        </View>
      )}
      renderItem={({item}) => (
        <View style={Estilo.fundoItem}>
          <Text style={Estilo.textoItem}>{item}</Text>
        </View >
      )}
      refreshControl={
        <RefreshControl
          refreshing={Atualizar}
          onRefresh={aoAtualizar}
        />
      }
    />
  );
}
const Estilo = StyleSheet.create({
  fundoItem: {borderBottomWidth: 1, justifyContent: 'center', alignItems: 'center'},
  fundoTitulo: {alignItems: 'center', backgroundColor: '#40F7A8', borderBottomWidth: 2, justifyContent: 'center'},
  textoTitulo: {color: '#000000', fontFamily: 'Bodoni 72', fontSize: 45, fontStyle: 'italic', margin: 10},
  textoItem: {color: '#000000', fontFamily: 'ArialMT', fontSize: 40, marginVertical: 10},
});