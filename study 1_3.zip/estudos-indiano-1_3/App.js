import React, {useState} from 'react';
import {Button, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  return (
    <View style={Estilos.Corpo}>
    <View style={Estilos.Estilo1}>
      <Text style={Estilos.Texto}>1</Text>
    </View>
    <View style={Estilos.Estilo2}>
      <Text style={Estilos.Texto}>2</Text>
    </View>
    <View style={Estilos.Estilo3}>
      <Text style={Estilos.Texto}>3</Text>
    </View>
    </View>
  );
}
const Estilos = StyleSheet.create({
  Corpo: {flex:1, flexDirection:'row', backgroundColor: '#0000ff', alignItems: 'stretch', justifyContent: 'center',},
  Estilo1: {flex:1, backgroundColor: '#00ffff', alignItems: 'center', justifyContent: 'center',},
  Estilo2: {flex:1, backgroundColor: '#ff00ff', alignItems: 'center', justifyContent: 'center',},
  Estilo3: {flex:1, backgroundColor: '#ffff00', alignItems: 'center', justifyContent: 'center',},
  Texto: {color: '#000000', fontSize: 40, fontStyle: 'italic', margin: 10,},
});
