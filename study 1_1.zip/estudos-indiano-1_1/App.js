import React, {useState} from 'react';
import {Button, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  const [nome, mudaNome] = useState('Mash')
  const [sessao, mudaSessao] = useState({numero: 6, titulo: 'status'})
  const [geral, mudaGeral] = useState(true)
  const quandoClicarMuda = () => {
    mudaNome('Estou programando com "Mash"')
    mudaSessao({numero: 7, titulo: 'Estilização'})
    mudaGeral(false)
  }
  return (
    <View style={Estilos.Corpo}>
      <Text style={Estilos.Texto}>{nome} </Text>
      <Text style={Estilos.Texto}> Esta é a sessão número {sessao.numero} sobre o: {sessao.titulo} </Text>
      <Text style={Estilos.Texto}>{geral? 'Atual Sessão':'Próxima sessão'} </Text>
      <Button title='Clique para mudar o nome' onPress={quandoClicarMuda}></Button>
    </View>
  );
}
const Estilos = StyleSheet.create({
  Corpo: {flex: 1, backgroundColor: '#0000ff', alignItems: 'center', justifyContent: 'center'},
  Texto: {color: '#ffffff', fontSize: 20, fontStyle: 'italic', margin: 10},
});
