import React, {useState} from 'react';
import {RefreshControl, ScrollView, SectionList, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';
export default function App() {
  const DADOS =[
    {
      título:'Título 1',
      data: ['Item 1-1', 'Item 1-2', 'Item 1-3'],
    },
    {
      título:'Título 2',
      data: ['Item 2-1', 'Item 2-2', 'Item 2-3'],
    },
    {
      título:'Título 3',
      data: ['Item 3-1', 'Item 3-2', 'Item 3-3'],
    },
    {
      título:'Título 4',
      data: ['Item 4-1', 'Item 4-2', 'Item 4-3'],
    },
  ]
  return (
    <SectionList
      keyExtractor={(item, caixa)=> caixa.toString()}
      sections={DADOS}
      renderItem={({item}) => (
          <Text style={Estilos.Texto}>{item}</Text>
      )}
      renderSectionHeader={({section}) => (
        <View style={Estilos.Item}>
          <Text style={Estilos.Texto}>{section.título}</Text>
        </View>
      )}
    />
  );
}
const Estilos = StyleSheet.create({
  Item: {margin:10, backgroundColor: '#4ae1fa', justifyContent: 'center', alignItems: 'center',},
  Texto: {color: '#000000', fontSize: 45, fontStyle: 'italic', margin: 10,},
});
