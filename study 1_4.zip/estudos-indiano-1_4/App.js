import React, {useState} from 'react';
import {RefreshControl, ScrollView, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  const [Itens, definirItens] = useState([
    {chave:1, item:'Item 1'},
    {chave:2, item:'Item 2'},
    {chave:3, item:'Item 3'},
    {chave:4, item:'Item 4'},
    {chave:5, item:'Item 5'},
    {chave:6, item:'Item 6'},
    {chave:7, item:'Item 7'},
    {chave:8, item:'Item 8'},
    {chave:44, item:'Item 9'},
    {chave:68, item:'Item 27'},
    {chave:70, item:'Item 78'},
  ]);
  const [Atualizar, definirAtualizar] = useState(false); 
  const aoAtualizar = () => {
    definirAtualizar(true);
    definirItens([...Itens, {chave: 69, item:'Item 69'}]);
    definirAtualizar(false);
    }
  return (
    <ScrollView style={Estilos.Corpo} refreshControl={
      <RefreshControl refreshing={Atualizar} onRefresh={aoAtualizar}
    colors={['#ff00ff']}/>
    }>
      {
        Itens.map((objeto)=>{return(
          <View style={Estilos.Item} key={objeto.chave}>
            <Text style={Estilos.Texto}>{objeto.item}</Text>
          </View>
        )})
      }
    </ScrollView>
  );
}
const Estilos = StyleSheet.create({
  Corpo: {flex:1, flexDirection:'column', backgroundColor: '#ffffff'},
  Item: {margin:10, backgroundColor: '#4ae1fa', justifyContent: 'center', alignItems: 'center',},
  Texto: {color: '#000000', fontSize: 45, fontStyle: 'italic', margin: 10,},
});
