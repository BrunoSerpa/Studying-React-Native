import React, {useState} from 'react';
import {Button, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  const [nome, mudaNome] = useState('Teste de eslização')
  const quandoClicarMuda = () => {
    mudaNome('O teste de estilização está feito!')
  }
  return (
    <View style={Estilos.Corpo}>
      <Text style={Estilos.Texto}>{nome}</Text>
      <View style={Estilos.Botão}>
      <Button title='Atualiza estados' onPress={quandoClicarMuda}></Button>
      </View>
    </View>
  );
}
const Estilos = StyleSheet.create({
  Corpo: {width:'100%', height:'50%', backgroundColor: '#ffff00',
    alignItems: 'center', justifyContent: 'center', borderWidth: 10,
    borderColor:'#ff00ff', borderRadius: 10}, 
  Texto: {color: '#000000', fontSize: 40, fontStyle: 'italic', margin: 10, textAlign:'center', textTransform:'upperCase'},
  Botão: {width:200, height:60}
});
