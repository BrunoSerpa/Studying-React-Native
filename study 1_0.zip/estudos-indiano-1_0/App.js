import React from 'react';
import {Button, Linking, StyleSheet, Text, View} from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  return (
    <View style={Estilos.Corpo}>
      <Text style={Estilos.Texto}> Programando com o "Mash"</Text>
      <Button title='O canal do indiano' onPress={()=>{Linking.openURL('https://www.youtube.com/programmingwithmash')}}></Button>
    </View>
  );
}
const Estilos = StyleSheet.create({
  Corpo: {flex: 1, backgroundColor: '#0000ff', alignItems: 'center', justifyContent: 'center'},
  Texto: {color: '#ffffff', fontSize: 20, fontStyle: 'italic', margin: 10},
});
